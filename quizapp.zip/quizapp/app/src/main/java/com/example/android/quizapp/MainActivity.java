package com.example.android.quizapp;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    int sum=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void submit(View view) {

        //--------------------------------------------------------
        CheckBox ap1 = (CheckBox) findViewById(R.id.ch1);
        boolean an1 = ap1.isChecked();
        if(an1){sum++;}
        CheckBox ap2 = (CheckBox) findViewById(R.id.ch2);
        boolean an2 = ap2.isChecked();
        if (an2){an1=false;}
        CheckBox ap3 = (CheckBox) findViewById(R.id.ch3);
        boolean an3 = ap3.isChecked();
        if (an3){an1=false;}
        CheckBox ap4 = (CheckBox) findViewById(R.id.ch4);
        boolean an4 = ap4.isChecked();
        if (an4){an1=false;}
       //--------------------------------------------------------
        CheckBox ap5 = (CheckBox) findViewById(R.id.ch5);
        boolean an5 = ap5.isChecked();
        if(an5){sum++;}
        CheckBox ap6 = (CheckBox) findViewById(R.id.ch6);
        boolean an6 = ap6.isChecked();
        if (an6){an5=false;}
        CheckBox ap7= (CheckBox) findViewById(R.id.ch7);
        boolean an7 = ap7.isChecked();
        if (an7){an5=false;}
        CheckBox ap8 = (CheckBox) findViewById(R.id.ch8);
        boolean an8 = ap8.isChecked();
        if (an8){an5=false;}
        //--------------------------------------------------------
        CheckBox ap9 = (CheckBox) findViewById(R.id.ch9);
        boolean an9 = ap9.isChecked();
        if(an9){sum++;}
        CheckBox ap10 = (CheckBox) findViewById(R.id.ch10);
        boolean an10 = ap10.isChecked();
        if (an10){an9=false;}
        CheckBox ap11 = (CheckBox) findViewById(R.id.ch11);
        boolean an11 = ap11.isChecked();
        if (an11){an9=false;}
        CheckBox ap12 = (CheckBox) findViewById(R.id.ch12);
        boolean an12 = ap12.isChecked();
        if (an12){an9=false;}
        //--------------------------------------------------------
        CheckBox ap13 = (CheckBox) findViewById(R.id.ch13);
        boolean an13 = ap13.isChecked();
        if(an13){sum++;}
        CheckBox ap14 = (CheckBox) findViewById(R.id.ch14);
        boolean an14 = ap14.isChecked();
        if (an14){an13=false;}
        CheckBox ap15 = (CheckBox) findViewById(R.id.ch15);
        boolean an15 = ap15.isChecked();
        if (an15){an13=false;}
        CheckBox ap16 = (CheckBox) findViewById(R.id.ch16);
        boolean an16 = ap16.isChecked();
        if (an16){an13=false;}
        //--------------------------------------------------------
        RadioButton ap17 = (RadioButton) findViewById(R.id.radio1);
        boolean an17=ap17.isChecked();
        if (an17){sum++;}
        RadioButton ap18 = (RadioButton) findViewById(R.id.radio2);
        boolean an18=ap18.isChecked();
        if (an18){an17=false;}
        //--------------------------------------------------------
        EditText ap19 = (EditText) findViewById(R.id.textAN);
        String an19 = ap19.getText().toString();
        boolean answer = false;
        if (an19.equals("8.000 miles")){
            answer=true;
            sum++;
        }
        //--------------------------------------------------------
        Context context = getApplicationContext();
        CharSequence text = "good job\n you have:"+sum+"points\n1)"+an1+"\n2)"+an5+"\n3)"+an9+"\n4)"+an13+"\n5)"+an17+"\n6)"+answer;
        if (sum==0){text = "Try again :(";}
        int duration=Toast.LENGTH_LONG;
        Toast toast=Toast.makeText(context,text,duration);
        toast.show();
        //--------------------------------------------------------
        if(ap1.isChecked()){
            ap1.toggle();}
        if(ap2.isChecked()){
            ap2.toggle();}
        if(ap3.isChecked()){
            ap3.toggle();}
        if(ap4.isChecked()){
            ap4.toggle();}
        if(ap5.isChecked()){
            ap5.toggle();}
        if(ap6.isChecked()){
            ap6.toggle();}
        if(ap7.isChecked()){
            ap7.toggle();}
        if(ap8.isChecked()){
            ap8.toggle();}
        if(ap9.isChecked()){
            ap9.toggle();}
        if(ap10.isChecked()){
            ap10.toggle();}
        if(ap11.isChecked()){
            ap11.toggle();}
        if(ap12.isChecked()){
            ap12.toggle();}
        if(ap13.isChecked()){
            ap13.toggle();}
        if(ap14.isChecked()){
            ap14.toggle();}
        if(ap15.isChecked()){
            ap15.toggle();}
        if(ap16.isChecked()){
            ap16.toggle();}
        ap17.setChecked(false);
        ap18.setChecked(false);
        ap19.setText(null);
        sum=0;








    }







    }








